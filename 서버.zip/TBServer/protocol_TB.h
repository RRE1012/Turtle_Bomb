#pragma once
#pragma pack (1)
struct cs_pos {
	char size;
	char type;
}

#pragma pack