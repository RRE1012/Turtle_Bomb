#pragma once

#include "stdafx.h"
#include "TB_Server.h"

int g_TotalSockets = 0;

Socket_Info *SocketInfoArray[WSA_MAXIMUM_WAIT_EVENTS];
WSAEVENT EventArray[WSA_MAXIMUM_WAIT_EVENTS];

list<Bomb_Pos> bomb_list;
int MapInfo[15][15];

//int MapInfo[225];
DWORD WINAPI Bomb_Count_Thread(LPVOID arg);
Packet_Char char_info[4]; //4���� ĳ���������� ��Ƶ���
int bomb_count1;
int bomb_count2;
bool bomb_Map[15][15]; //��ź on/off
Bomb_Pos bombs[225];
int g_total_member = 0;
void err_quit(char* msg);
void err_display(char* msg);
BOOL AddSOCKETInfo(SOCKET sock);
void RemoveSocketInfo(int nIndex);
void err_display(int errcode);
DWORD g_prevTime2;
list<PosOfBOMB> g_bomb_explode;
int map = 3;
void ArrayMap();
int main(int argc, char* argv[]) {
	/*
	for (int x = 0; x < 15; ++x) {
		for (int y = 0; y < 15; ++y) {
			MapInfo[(x * 15) + y] = 2;
		}
		
	}

	for (int i = 2; i < 13; ++i) {
		if (rand() % 15 < 1) {
			MapInfo[i] = 1;//'B';
		}
		else if (rand() % 15 < 5) {
			MapInfo[i] = 2;//'N'
		}
		else if (rand() % 15 < 9) {
			MapInfo[i] = 3;//'C'
		}
		else if (rand() % 15 < 13) {
			MapInfo[i] = 4;//'R'
		}
		else
			MapInfo[i] = 5;//'I'

		if (rand() % 15 < 1) {
			MapInfo[i+15] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[i + 15] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[i + 15] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[i + 15] = 4;
		}
		else
			MapInfo[i + 15] = 5;

		if (rand() % 15 < 1) {
			MapInfo[i*15] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[i * 15] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[i * 15] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[i * 15] = 4;
		}
		else
			MapInfo[i * 15] = 5;

		if (rand() % 15 < 1) {
			MapInfo[(i * 15)+1] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[(i * 15) + 1] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[(i * 15) + 1] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[(i * 15) + 1] = 4;
		}
		else
			MapInfo[(i * 15) + 1] = 5;
		if (rand() % 15 < 1) {
			MapInfo[i+14] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[i+14] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[i+14] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[i+14] = 4;
		}
		else
			MapInfo[i+14] = 5;

		if (rand() % 15 < 1) {
			MapInfo[i+13] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[i+13] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[i+13] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[i+13] = 4;
		}
		else
			MapInfo[i+13] = 5;

		if (rand() % 15 < 1) {
			MapInfo[(14*15)+i] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[(14 * 15) + i] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[(14 * 15) + i] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[(14 * 15) + i] = 4;
		}
		else
			MapInfo[(14 * 15) + i] = 5;

		if (rand() % 15 < 1) {
			MapInfo[(13 * 15) + i] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[(13 * 15) + i] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[(13 * 15) + i] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[(13 * 15) + i] = 4;
		}
		else
			MapInfo[(13 * 15) + i] = 5;


		for (int j = 2; j < 13; ++j) {
			if (rand() % 15 < 1) {
				MapInfo[(i*15)+j] = 1;
			}
			else if (rand() % 15 < 5) {
				MapInfo[(i * 15) + j] = 2;
			}
			else if (rand() % 15 < 9) {
				MapInfo[(i * 15) + j] = 3;
			}
			else if (rand() % 15 < 13) {
				MapInfo[(i * 15) + j] = 4;
			}

			else
				MapInfo[(i * 15) + j] = 5;
			
		}
		

	}
	
	for (int x = 0; x < 15; ++x) {
		for (int y = 0; y < 15; ++y) {
			if (MapInfo[(x * 15) + y]==1) {
				printf("B  ");
			}
			else if (MapInfo[(x * 15) + y] == 2) {
				printf("N  ");
			}
			else if (MapInfo[(x * 15) + y] == 3) {
				printf("C  ");
			}
			else if (MapInfo[(x * 15) + y] == 4) {
				printf("R  ");
			}
			else if (MapInfo[(x * 15) + y] == 5) {
				printf("I  ");
			}

			
		}
		printf("\n");
	}
	*/
	ArrayMap();
	HANDLE hThread;
	hThread = CreateThread(NULL, 0, Bomb_Count_Thread, NULL, 0, NULL);
	int retval;
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 0;
	SOCKET listen_sock = socket(AF_INET,SOCK_STREAM,0);
	if (listen_sock == INVALID_SOCKET)
		err_quit("socket()");
	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(TB_SERVER_PORT);
	retval = ::bind(listen_sock, (SOCKADDR*)&serveraddr, sizeof(serveraddr));
	if(retval==SOCKET_ERROR)
		err_quit("bind()");
	retval = listen(listen_sock, SOMAXCONN);
	if (retval == SOCKET_ERROR)
		err_quit("listen()");
	//���� ���� �߰�&WSAEventSelect
	AddSOCKETInfo(listen_sock);
	retval = WSAEventSelect(listen_sock, EventArray[g_TotalSockets - 1],FD_ACCEPT|FD_CLOSE);
	if (retval == SOCKET_ERROR)
		err_quit("WSAEventSelect()");

	WSANETWORKEVENTS m_NetworkEvents;
	SOCKET client_sock;
	SOCKADDR_IN clientaddr;
	int i, addrlen;
	

	while (1) {
		//�̺�Ʈ ��ü �����ϱ�
		i = WSAWaitForMultipleEvents(g_TotalSockets, EventArray, FALSE, WSA_INFINITE, FALSE);
		if (i == WSA_WAIT_FAILED)
			continue;
		i -= WSA_WAIT_EVENT_0;
		//��ü���� ��Ʈ��ũ �̺�Ʈ �˾Ƴ���
		retval = WSAEnumNetworkEvents(SocketInfoArray[i]->sock, EventArray[i], &m_NetworkEvents);
		if (retval == SOCKET_ERROR)
			continue;
		//FD_ACCEPT �̺�Ʈ ó��
		if (m_NetworkEvents.lNetworkEvents&FD_ACCEPT) {
			if (m_NetworkEvents.iErrorCode[FD_ACCEPT_BIT] != 0) {
				err_display(m_NetworkEvents.iErrorCode[FD_ACCEPT_BIT]);
				continue;
			}
			addrlen = sizeof(clientaddr);
			client_sock = accept(SocketInfoArray[i]->sock, (SOCKADDR*)&clientaddr, &addrlen);
			if (client_sock == INVALID_SOCKET) {
				err_display("accept()");
				continue;
			}
			printf("[TCP ����] Ŭ���̾�Ʈ ���� : IP �ּ� =%s, ��Ʈ��ȣ=%d\n",inet_ntoa(clientaddr.sin_addr),ntohs(clientaddr.sin_port));
			retval = send(client_sock, (char*)&g_total_member, sizeof(int), 0);
			printf("����-%d��° -ID : %d\n", i,g_total_member);

			g_total_member++;
			/*
			for (int x = 0; x < 15; ++x) {
				for (int y = 0; y < 15; ++y) {
					retval = send(client_sock, (char*)&MapInfo[x][y], sizeof(char), 0);
				}
			}
			*/
			retval = send(client_sock, (char*)&MapInfo, sizeof(MapInfo), 0);
			printf("������ ���� :%d����Ʈ\n", retval);
			retval = send(client_sock, (char*)&map, sizeof(int), 0);

			if (g_TotalSockets >= WSA_MAXIMUM_WAIT_EVENTS) {
				printf("[����] �� �̻� ������ �޾Ƶ��� �� �����ϴ�!!!!!\n");
				closesocket(client_sock);
				continue;
			}
			
			if (retval == SOCKET_ERROR) {
				if (WSAGetLastError() != WSAEWOULDBLOCK) {
					err_display("send()");
					RemoveSocketInfo(i);
				}
				continue;
			}
			//
			//���� ���� �߰�
			AddSOCKETInfo(client_sock);
			
			retval = WSAEventSelect(client_sock, EventArray[g_TotalSockets - 1], FD_READ | FD_WRITE | FD_CLOSE);
			if (retval == SOCKET_ERROR)
				err_quit("WSAEventSelect()-client");

		}
		if (m_NetworkEvents.lNetworkEvents&FD_READ || m_NetworkEvents.lNetworkEvents&FD_WRITE) {
			if (m_NetworkEvents.lNetworkEvents&FD_READ &&m_NetworkEvents.iErrorCode[FD_READ_BIT] != 0) {
				err_display(m_NetworkEvents.iErrorCode[FD_READ_BIT]);
				continue;
			}
			if (m_NetworkEvents.lNetworkEvents&FD_WRITE &&m_NetworkEvents.iErrorCode[FD_WRITE_BIT] != 0) {
				err_display(m_NetworkEvents.iErrorCode[FD_WRITE_BIT]);
				continue;
			}
			Socket_Info* ptr = SocketInfoArray[i];
			float m_turtle1_posx;
			float m_turtle1_posz;
			float m_turtle1_roty;
			int m_temp_id=0;
			Bomb_Pos m_tempbombinfo;
			if (ptr->recvbytes == 0) {
				//������ �ޱ�
				retval = recv(ptr->sock, (char*)&ptr->type, sizeof(int), 0);
				
				switch (ptr->type) {
				case 1:
					recv(ptr->sock, (char*)&m_temp_id, sizeof(int), 0);
					recv(ptr->sock, (char*)&m_turtle1_posx, sizeof(float), 0);

					recv(ptr->sock, (char*)&m_turtle1_posz, sizeof(float), 0);
					recv(ptr->sock, (char*)&m_turtle1_roty, sizeof(float), 0);
					
					char_info[m_temp_id].x = m_turtle1_posx;
					char_info[m_temp_id].z = m_turtle1_posz;
					char_info[m_temp_id].rotY = m_turtle1_roty;
					/*
					for (int j = 1; j < g_total_member+1; ++j) {
						retval = send(SocketInfoArray[j]->sock, (char*)&char_info[m_temp_id - 1], sizeof(Packet_Char), 0); //
						printf("ĳ���� ������ ���´�!\n");
					}*/
					printf("ĳ���� ������ �޾Ҵ�!\n");
					break;
				case 2:
					int x;
					int y;
					printf("what?\n");
					recv(ptr->sock, (char*)&x, sizeof(int), 0);
					recv(ptr->sock, (char*)&y, sizeof(int), 0);
					//bomb_Map[x][y] = true;
					MapInfo[x][y] = 1;
					m_tempbombinfo = { x, y, true, 0.0f };
					bomb_list.emplace_back(m_tempbombinfo);
					printf("��ź ������ �޾Ҵ�!\n");
					break;
				case 3:
					int x2;
					int y2;
					recv(ptr->sock, (char*)&x2, sizeof(int), 0);
					recv(ptr->sock, (char*)&y2, sizeof(int), 0);
					bomb_Map[x2][y2] = false;

					break;
				}
				


				if (retval == SOCKET_ERROR) {
					if (WSAGetLastError() != WSAEWOULDBLOCK) {
						err_display("recv()");
						RemoveSocketInfo(i);
					}
					continue;
				}
				
				ptr->recvbytes = retval;
				//���� ������ ���
				/*
				ptr->buf[retval] = '\0';
				*/
				addrlen = sizeof(clientaddr);
				
				getpeername(ptr->sock, (SOCKADDR*)&clientaddr, &addrlen);
				printf("[TCP/%s:%d] TurtlePosx,z : %f,%f, \n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port), m_turtle1_posx, m_turtle1_posz);
				
			}
			if (ptr->recvbytes > ptr->sendbytes) {
				//������ ������
				int temptype = 1;
				
				retval = send(ptr->sock, (char*)&temptype, sizeof(int), 0);
				//for (int player = 0; player < g_total_member; ++player) {
					for (int j = 0; j < 4; ++j) {
						retval = send(ptr->sock, (char*)&char_info[j], sizeof(Packet_Char), 0);
						printf("%d����Ʈ ���´�!!!\n", retval);
					}
				//}
				printf("���´�!!!\n");
				int temptype2 = 2;
				retval = send(ptr->sock, (char*)&temptype2, sizeof(int), 0);
				retval = send(ptr->sock, (char*)&MapInfo, sizeof(MapInfo), 0);
				printf("%d����Ʈ �������� ���´�!!!\n", retval);
				if (retval == SOCKET_ERROR) {
					if (WSAGetLastError() != WSAEWOULDBLOCK) {
						err_display("send()");
						RemoveSocketInfo(i);
					}
					continue;
				}
				ptr->sendbytes += retval;
				//���� �� ==
				if (ptr->recvbytes <= ptr->sendbytes)
					ptr->recvbytes = ptr->sendbytes = 0;
			}
			//������ ��ź�� �ִٸ�
			if(g_bomb_explode.size()>0){
				int m_temptype = 3;

				list<PosOfBOMB>::iterator b = g_bomb_explode.begin();

				for (; b != g_bomb_explode.end(); ++b) {
					send(ptr->sock, (char*)&m_temptype, sizeof(int), 0);
					send(ptr->sock, (char*)&b, sizeof(PosOfBOMB), 0);

				}

				//��retval = send(ptr->sock, (char*)&char_info[j], sizeof(Packet_Char), 0);
			}
		}
		//FD_CLOSE �̺�Ʈ ó��
		if (m_NetworkEvents.lNetworkEvents&FD_CLOSE) {
			if (m_NetworkEvents.iErrorCode[FD_CLOSE_BIT] != 0) {
				err_display(m_NetworkEvents.iErrorCode[FD_CLOSE_BIT]);
			}
			RemoveSocketInfo(i);
		}
	}
	WSACleanup();
	return 0;

}



void err_display(char *msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char *)lpMsgBuf);
	LocalFree(lpMsgBuf);
}

void err_quit(char* msg) {
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, msg, MB_ICONERROR);
	LocalFree(lpMsgBuf);
	exit(1);
}
void err_display(int errcode) {
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, WSAGetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[����]%s", (char*)lpMsgBuf);
	LocalFree(lpMsgBuf);
}
BOOL AddSOCKETInfo(SOCKET sock) {
	Socket_Info* ptr = new Socket_Info;
	if (ptr == NULL) {
		printf("Not enough Memory!!!\n");
		return FALSE;
	}
	WSAEVENT hEvent = WSACreateEvent();
	if (hEvent == WSA_INVALID_EVENT) {
		err_display("WSACreateEvent()");
		return FALSE;
	}
	ptr->sock = sock;
	ptr->recvbytes = 0;
	ptr->sendbytes = 0;
	SocketInfoArray[g_TotalSockets] = ptr;
	EventArray[g_TotalSockets] = hEvent;
	++g_TotalSockets;
	printf("��ϿϷ�\n");
	return TRUE;
}
void RemoveSocketInfo(int nIndex) {
	Socket_Info* ptr = SocketInfoArray[nIndex];

	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	getpeername(ptr->sock, (SOCKADDR*)&clientaddr, &addrlen);
	printf("TCP���� Ŭ���̾�Ʈ ����:IP �ּ�=%s,��Ʈ��ȣ = %d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
	closesocket(ptr->sock);
	delete ptr;
	WSACloseEvent(EventArray[nIndex]);
	if (nIndex != (g_TotalSockets - 1)) {
		SocketInfoArray[nIndex] = SocketInfoArray[g_TotalSockets - 1];
		EventArray[nIndex] = EventArray[g_TotalSockets - 1];

	}
	--g_TotalSockets;

}


DWORD WINAPI Bomb_Count_Thread(LPVOID arg) {
	float m_testtime = 0.0f;
	while (1) {
		DWORD currTime = GetTickCount();
		DWORD elapsedTime = currTime - g_prevTime2;
		
		g_prevTime2 = currTime;
		list<Bomb_Pos>::iterator k = bomb_list.begin();
		if (bomb_list.size()>0) {
			
			for (; k != bomb_list.end(); ++k) {

				if (k->is_set) {
					k->settime = k->settime + ((float)elapsedTime / 1000);
				}
				else {
					k = bomb_list.erase(k);
				}
				if (k->settime >= 3.0f) {
					MapInfo[k->posx][k->posz] = 2;
					//bomb_Map[k->posx][k->posz] = false;
					k->is_set = false;
					k->settime = 0.0f;
					PosOfBOMB pos = {k->posx,k->posz};
					g_bomb_explode.emplace_back(pos);
					printf("��ź����\n");
				}

			}
			
		}
		else {
			m_testtime = m_testtime + ((float)elapsedTime / 1000);
			//printf("m_testtime = %f\n", m_testtime);
			if (m_testtime > 2.0f) {
				printf("��ź����\n");
				m_testtime = 0.0f;

			}
		}
		
		/*
		for (int j = 0; j < 225; ++j) {
			if (bombs[j].is_set) {
				bombs[j].settime = bombs[j].settime + ((float)elapsedTime / 1000);

			}
			if (bombs[j].settime >= 2.0f) {
				//��ź�� ���Ľ�Ű��� ����

				//�ٽ� false��
				bombs[j].is_set = false;
				bombs[j].settime = 0.0f;
			}

		}
		*/
	}
	return 0;
	
}







void ArrayMap() {

	char_info[0].hp = 10.0f;
	char_info[0].x = 0.0f;
	char_info[0].z =0.0f;
	char_info[0].is_alive = true;
	char_info[0].rotY = 0.0f;
	char_info[1].hp = 10.0f;
	char_info[1].x = 28.0f;
	char_info[1].z = 0.0f;
	char_info[1].is_alive = true;
	char_info[1].rotY = 0.0f;
	char_info[2].hp = 10.0f;
	char_info[2].x = 0.0f;
	char_info[2].z = 28.0f;
	char_info[2].is_alive = true;
	char_info[2].rotY = 180.0f;
	char_info[3].hp = 10.0f;
	char_info[3].x = 28.0f;
	char_info[3].z = 28.0f;
	char_info[3].is_alive = true;
	char_info[3].rotY = 180.0f;



	for (int x = 0; x < 15; ++x) {
		for (int y = 0; y < 15; ++y) {
			MapInfo[x][y] = 2;
		}

	}

	for (int i = 2; i < 13; ++i) {
		if (rand() % 15 < 1) {
			MapInfo[i][0] = 1;//'B';
		}
		else if (rand() % 15 < 5) {
			MapInfo[i][0] = 2;//'N'
		}
		else if (rand() % 15 < 9) {
			MapInfo[i][0] = 3;//'C'
		}
		else if (rand() % 15 < 13) {
			MapInfo[i][0] = 4;//'R'
		}
		else
			MapInfo[i][0] = 5;//'I'

		if (rand() % 15 < 1) {
			MapInfo[i][1] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[i][1] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[i][1] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[i][1] = 4;
		}
		else
			MapInfo[i][1] = 5;

		if (rand() % 15 < 1) {
			MapInfo[i][1] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[i][1] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[i][1] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[i][1] = 4;
		}
		else
			MapInfo[i][1] = 5;

		if (rand() % 15 < 1) {
			MapInfo[i][14] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[i][14] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[i][14] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[i][14] = 4;
		}
		else
			MapInfo[i][14] = 5;
		if (rand() % 15 < 1) {
			MapInfo[i][13] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[i][13] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[i][13] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[i][13] = 4;
		}
		else
			MapInfo[i][13] = 5;

		if (rand() % 15 < 1) {
			MapInfo[0][i] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[0][i] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[0][i] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[0][i] = 4;
		}
		else
			MapInfo[0][i] = 5;

		if (rand() % 15 < 1) {
			MapInfo[1][i] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[1][i] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[1][i] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[1][i] = 4;
		}
		else
			MapInfo[1][i] = 5;

		if (rand() % 15 < 1) {
			MapInfo[13][i] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[13][i] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[13][i] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[13][i] = 4;
		}
		else
			MapInfo[13][i] = 5;
		if (rand() % 15 < 1) {
			MapInfo[14][i] = 1;
		}
		else if (rand() % 15 < 5) {
			MapInfo[14][i] = 2;
		}
		else if (rand() % 15 < 9) {
			MapInfo[14][i] = 3;
		}
		else if (rand() % 15 < 13) {
			MapInfo[14][i] = 4;
		}
		else
			MapInfo[14][i] = 5;


		for (int j = 2; j < 13; ++j) {
			if (rand() % 15 < 1) {
				MapInfo[i][j] = 1;
			}
			else if (rand() % 15 < 5) {
				MapInfo[i][j] = 2;
			}
			else if (rand() % 15 < 9) {
				MapInfo[i][j] = 3;
			}
			else if (rand() % 15 < 13) {
				MapInfo[i][j] = 4;
			}

			else
				MapInfo[i][j] = 5;

		}


	}

	for (int x = 0; x < 15; ++x) {
		for (int y = 0; y < 15; ++y) {
			if (MapInfo[x][y] == 1) {
				printf("B  ");
			}
			else if (MapInfo[x][y] == 2) {
				printf("N  ");
			}
			else if (MapInfo[x][y] == 3) {
				printf("C  ");
			}
			else if (MapInfo[x][y] == 4) {
				printf("R  ");
			}
			else if (MapInfo[x][y] == 5) {
				printf("I  ");
			}


		}
		printf("\n");
	}

}




